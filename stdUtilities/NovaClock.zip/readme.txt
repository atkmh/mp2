NovaClock 1.5.0.82 Beta

ZIP file contains...

NovaClock.exe		NovaClock executable
*.scheme		schemes
*.picture		scheme pictures

To install the beta version copy NovaClock.exe into your program 
folder (e.g. C:\Programs\NovaClock\).
To get the schemes, start NovaClock and in the context menu 
select "Properties" to open the options dialog and select the 
tab "Scheme". There you'll find a link to where NovaClock stores 
your personal scheme files. Click the link to open the directory. 
Put the *.scheme and *.picture files into this directoy. Then 
reopen the Properties dialog to update the scheme list. Select 
one of the schemes and be suprised, how NovaClock can look like.


If you have questions or suggestions, feel free to contact me at 
www.novacom.net/novaclock or bugs.novaclock@novacom.net.

Thanx and bye.
