package jadx.core.dex.instructions;

import jadx.core.dex.info.MethodInfo;

public interface CallMthInterface {

	MethodInfo getCallMth();
}
