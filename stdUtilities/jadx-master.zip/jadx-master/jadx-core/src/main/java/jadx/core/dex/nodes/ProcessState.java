package jadx.core.dex.nodes;

public enum ProcessState {
	NOT_LOADED,
	STARTED,
	PROCESSED,
	GENERATED,
	UNLOADED
}
