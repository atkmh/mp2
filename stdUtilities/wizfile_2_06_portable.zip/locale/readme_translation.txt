Unzip to the [WizFile]\locale folder (normally C:\Program Files\WizFile)

The folder structure for translation files is
[WizFile]\locale\XX\LC_MESSAGES\default.mo
[WizFile]\locale\XX\LC_MESSAGES\default.po

where XX is the language code

Restart WizFile, then select Options->Language and select the language. 
If WizFile does not detect the new language check that you're using the correct folder structure.



